A problem report prepared by GeoComp 0.1.0 (QGIS 3.44.7-Solothurn) on Linux-6.14.0-37-generic-x86_64-with-glibc2.39.

Engine: DynAdjust, version not recorded
Reported to: https://github.com/GeoscienceAustralia/DynAdjust/issues

What ran, in order, in /home/kaue/geocomp/synthetic_examples/07_project/project_package_engine_problem/example_3_dynadjust_singular_adjustment/inputs/dynadjust_adjust_work_dir:
  dnaimport
    $ /usr/bin/python3 -c print('dnaimport ok')
    exit code 0 after 0.0 s
  dnaadjust
    $ /usr/bin/python3 -c import sys; sys.stderr.write('Singular normal matrix\n'); sys.exit(3)
    exit code 3 after 0.0 s

Each program's whole output is in geocomp-<program>.stdout.txt and geocomp-<program>.stderr.txt.
geocomp-runs.jsonl records each run. The other files are the inputs, the configuration and whatever
the engine wrote, as they stood when this was packaged.

Before sending: these files are a survey's data, and the commands name folders on the computer
that ran them. Remove what may not be shared; GeoComp has left everything in.
